export declare const PolkadotJS: () => import("react/jsx-runtime").JSX.Element;
export default PolkadotJS;
