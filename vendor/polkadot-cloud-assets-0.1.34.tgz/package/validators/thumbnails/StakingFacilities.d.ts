declare const StakingFacilities: () => import("react/jsx-runtime").JSX.Element;
export default StakingFacilities;
