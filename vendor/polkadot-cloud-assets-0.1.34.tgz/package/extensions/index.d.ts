import { ExtensionConfig, HardwareConfig, ExtensionIconRecords, ExtensionIcon } from "../types";
export declare const Extensions: Record<string, ExtensionConfig>;
export declare const ExtensionsArray: {
    title: string;
    website: string | [string, string];
    features: "*" | import("../types").ExtensionFeature[];
    id: string;
}[];
export declare const ExtensionIcons: ExtensionIconRecords;
export declare const Hardware: Record<string, HardwareConfig>;
export declare const HardwareArray: {
    title: string;
    website: string | [string, string];
    id: string;
}[];
export declare const HardwareIcons: ExtensionIconRecords;
export declare const getExtensionIcon: (id: string) => ExtensionIcon | null;
