declare const DragonStake: () => import("react/jsx-runtime").JSX.Element;
export default DragonStake;
