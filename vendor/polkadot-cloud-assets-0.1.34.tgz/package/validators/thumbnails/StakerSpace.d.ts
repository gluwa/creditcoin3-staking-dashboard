declare const StakerSpace: () => import("react/jsx-runtime").JSX.Element;
export default StakerSpace;
