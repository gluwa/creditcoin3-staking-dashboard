declare const Stakenode: () => import("react/jsx-runtime").JSX.Element;
export default Stakenode;
