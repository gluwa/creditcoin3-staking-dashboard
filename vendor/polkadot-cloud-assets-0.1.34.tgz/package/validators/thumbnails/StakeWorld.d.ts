declare const StakeWorld: () => import("react/jsx-runtime").JSX.Element;
export default StakeWorld;
