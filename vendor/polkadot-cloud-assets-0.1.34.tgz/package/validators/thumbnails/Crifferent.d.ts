declare const Crifferent: () => import("react/jsx-runtime").JSX.Element;
export default Crifferent;
