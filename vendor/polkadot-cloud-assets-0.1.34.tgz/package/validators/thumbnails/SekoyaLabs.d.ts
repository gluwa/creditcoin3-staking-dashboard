declare const SekoyaLabs: () => import("react/jsx-runtime").JSX.Element;
export default SekoyaLabs;
