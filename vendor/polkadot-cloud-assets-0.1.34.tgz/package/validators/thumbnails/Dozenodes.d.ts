declare const Dozenodes: () => import("react/jsx-runtime").JSX.Element;
export default Dozenodes;
