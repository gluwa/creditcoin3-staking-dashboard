declare const PythagorasCapitalInvestment: () => import("react/jsx-runtime").JSX.Element;
export default PythagorasCapitalInvestment;
