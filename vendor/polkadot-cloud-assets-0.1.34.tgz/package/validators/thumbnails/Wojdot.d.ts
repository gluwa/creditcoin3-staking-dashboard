declare const Wojdot: () => import("react/jsx-runtime").JSX.Element;
export default Wojdot;
