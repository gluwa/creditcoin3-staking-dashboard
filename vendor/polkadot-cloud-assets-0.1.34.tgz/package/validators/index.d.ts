import { ValidatorConfig } from "../types";
export declare const ValidatorCommunity: ValidatorConfig[];
