declare const Decentradot: () => import("react/jsx-runtime").JSX.Element;
export default Decentradot;
