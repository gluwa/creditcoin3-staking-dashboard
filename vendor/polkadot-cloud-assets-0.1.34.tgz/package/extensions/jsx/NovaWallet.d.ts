export declare const NovaWallet: () => import("react/jsx-runtime").JSX.Element;
export default NovaWallet;
