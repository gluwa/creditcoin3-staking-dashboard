declare const Blockshard: () => import("react/jsx-runtime").JSX.Element;
export default Blockshard;
