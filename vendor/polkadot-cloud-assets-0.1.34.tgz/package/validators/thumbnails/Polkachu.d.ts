declare const Polkachu: () => import("react/jsx-runtime").JSX.Element;
export default Polkachu;
