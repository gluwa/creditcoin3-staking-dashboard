declare const HighStake: () => import("react/jsx-runtime").JSX.Element;
export default HighStake;
