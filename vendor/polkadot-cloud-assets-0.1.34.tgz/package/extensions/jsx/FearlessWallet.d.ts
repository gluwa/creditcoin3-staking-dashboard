export declare const FearlessWallet: () => import("react/jsx-runtime").JSX.Element;
export default FearlessWallet;
