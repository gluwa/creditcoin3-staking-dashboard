import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
var StakingFacilities = function () { return (_jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 600 600", children: [_jsx("defs", { children: _jsxs("linearGradient", { id: "linear-gradient", y1: 300, x2: 600, y2: 300, gradientUnits: "userSpaceOnUse", children: [_jsx("stop", { offset: 0, stopColor: "#141b30" }), _jsx("stop", { offset: 1, stopColor: "#1c3d6f" })] }) }), _jsx("path", { style: {
                stroke: "#010101",
                strokeMiterlimit: 10,
                fill: "url(#linear-gradient)",
            }, d: "M0 0h600v600H0z" }), _jsx("path", { fill: "#fff", d: "M498.16 210.2v-21.48l-142.45-68.44-253.87 52.52v23.87l251.48-39.79 144.84 53.32z" }), _jsx("path", { fill: "#fff", d: "M498.16 219.75v22.29L334.22 210.2l-232.38 26.27V210.2l238.75-36.6 157.57 46.15z" }), _jsx("path", { fill: "#fff", d: "M498.16 252.38v23.08L319.1 263.92l-217.26 11.54v-27.85l219.65-19.9 176.67 24.67zM498.16 287.4v23.87l-198.47 6.37-197.85-6.37V287.4l202.14-5.57 194.18 5.57zM498.16 324v24.15l-217.45 25.42-178.87-27.96V324l180.78 13.34L498.16 324z" }), _jsx("path", { fill: "#fff", d: "M498.16 362.77v24.79l-235.89 38.77-160.43-46.4v-22.88l162.34 34.64 233.98-28.92z" }), _jsx("path", { fill: "#fff", d: "M101.84 388.19v21.61l143.28 69.92 253.04-53.39v-24.79l-251.14 41.95-145.18-55.3z" })] })); };
export default StakingFacilities;


