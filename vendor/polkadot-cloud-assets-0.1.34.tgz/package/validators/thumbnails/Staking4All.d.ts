declare const Staking4All: () => import("react/jsx-runtime").JSX.Element;
export default Staking4All;
