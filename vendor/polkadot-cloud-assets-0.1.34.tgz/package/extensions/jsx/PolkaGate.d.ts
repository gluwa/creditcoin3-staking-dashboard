export declare const PolkaGate: () => import("react/jsx-runtime").JSX.Element;
export default PolkaGate;
