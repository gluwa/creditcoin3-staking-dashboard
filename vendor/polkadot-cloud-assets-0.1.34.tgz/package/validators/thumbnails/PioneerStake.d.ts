declare const PionerStake: () => import("react/jsx-runtime").JSX.Element;
export default PionerStake;
