declare const CoinbaseCloud: () => import("react/jsx-runtime").JSX.Element;
export default CoinbaseCloud;
