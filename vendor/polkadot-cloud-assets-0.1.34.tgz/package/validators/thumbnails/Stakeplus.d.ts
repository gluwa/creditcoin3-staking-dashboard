declare const Stakeplus: () => import("react/jsx-runtime").JSX.Element;
export default Stakeplus;
