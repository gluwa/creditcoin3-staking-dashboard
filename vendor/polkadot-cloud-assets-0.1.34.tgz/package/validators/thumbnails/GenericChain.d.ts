declare const GenericChain: () => import("react/jsx-runtime").JSX.Element;
export default GenericChain;
