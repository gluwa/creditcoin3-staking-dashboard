declare const Amforc: () => import("react/jsx-runtime").JSX.Element;
export default Amforc;
