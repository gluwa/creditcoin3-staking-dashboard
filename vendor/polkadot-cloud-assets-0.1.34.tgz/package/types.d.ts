import { CSSProperties, FC } from "react";
export interface ExtensionConfig {
    title: string;
    website: string | [string, string];
    features: "*" | ExtensionFeature[];
}
export type ExtensionFeature = "getAccounts" | "subscribeAccounts" | "signer";
export interface HardwareConfig {
    title: string;
    website: string | [string, string];
}
export type ValidatorSupportedChains = "polkadot" | "kusama" | "westend";
export interface ValidatorConfig {
    name: string;
    thumbnail: string;
    bio: string;
    email?: string;
    twitter?: string;
    website?: string;
    validators: Partial<{
        [K in ValidatorSupportedChains]: string[];
    }>;
}
export type ExtensionIconRecords = Record<string, ExtensionIcon>;
export type ExtensionIcon = FC<{
    style?: CSSProperties;
    className?: string;
}>;
declare global {
    interface Window {
        walletExtension?: any;
    }
}
