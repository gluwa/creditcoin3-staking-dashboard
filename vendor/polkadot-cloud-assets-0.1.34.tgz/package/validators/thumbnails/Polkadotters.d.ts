declare const Polkadotters: () => import("react/jsx-runtime").JSX.Element;
export default Polkadotters;
