declare const ApertureMining: () => import("react/jsx-runtime").JSX.Element;
export default ApertureMining;
