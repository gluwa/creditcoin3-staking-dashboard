declare const Blockseeker: () => import("react/jsx-runtime").JSX.Element;
export default Blockseeker;
