import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
var CoinbaseCloud = function () { return (_jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 64 64", children: [_jsx("path", { style: {
                fill: "#45e1e5",
            }, d: "M0 0h64v64H0z" }), _jsx("path", { d: "M32 43a11 11 0 1 1 10.83-12.83h11.09a22 22 0 1 0 0 3.66H42.83A11 11 0 0 1 32 43Z", style: {
                fill: "#0a0b0d",
            } })] })); };
export default CoinbaseCloud;


