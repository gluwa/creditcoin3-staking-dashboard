export declare const MetaMask: () => import("react/jsx-runtime").JSX.Element;
export default MetaMask;
