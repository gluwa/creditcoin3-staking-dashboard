declare const VFValidierung: () => import("react/jsx-runtime").JSX.Element;
export default VFValidierung;
