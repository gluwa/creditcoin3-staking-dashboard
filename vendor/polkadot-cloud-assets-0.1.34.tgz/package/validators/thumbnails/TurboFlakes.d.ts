declare const TurboFlakes: () => import("react/jsx-runtime").JSX.Element;
export default TurboFlakes;
