export declare const LedgerSquare: () => import("react/jsx-runtime").JSX.Element;
export default LedgerSquare;
