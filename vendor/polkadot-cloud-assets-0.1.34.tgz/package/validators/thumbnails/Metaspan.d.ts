declare const Metaspan: () => import("react/jsx-runtime").JSX.Element;
export default Metaspan;
