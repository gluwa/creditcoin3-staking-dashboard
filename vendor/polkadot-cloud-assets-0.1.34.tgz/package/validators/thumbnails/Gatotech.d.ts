declare const Gatotech: () => import("react/jsx-runtime").JSX.Element;
export default Gatotech;
