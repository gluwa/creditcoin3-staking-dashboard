export declare const SubwalletJS: () => import("react/jsx-runtime").JSX.Element;
export default SubwalletJS;
