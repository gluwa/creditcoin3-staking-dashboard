declare const Stakely: () => import("react/jsx-runtime").JSX.Element;
export default Stakely;
