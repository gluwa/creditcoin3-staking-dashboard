declare const Helikon: () => import("react/jsx-runtime").JSX.Element;
export default Helikon;
