export declare const Enkrypt: () => import("react/jsx-runtime").JSX.Element;
export default Enkrypt;
