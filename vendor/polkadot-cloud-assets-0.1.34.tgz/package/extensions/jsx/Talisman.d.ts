export declare const Talisman: () => import("react/jsx-runtime").JSX.Element;
export default Talisman;
