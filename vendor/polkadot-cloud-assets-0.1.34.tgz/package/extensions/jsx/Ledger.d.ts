export declare const Ledger: () => import("react/jsx-runtime").JSX.Element;
export default Ledger;
