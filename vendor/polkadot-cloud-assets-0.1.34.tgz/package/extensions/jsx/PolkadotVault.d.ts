export declare const PolkadotVault: () => import("react/jsx-runtime").JSX.Element;
export default PolkadotVault;
