declare const PDP: () => import("react/jsx-runtime").JSX.Element;
export default PDP;
