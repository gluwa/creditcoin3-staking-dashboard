declare const Dionysus: () => import("react/jsx-runtime").JSX.Element;
export default Dionysus;
