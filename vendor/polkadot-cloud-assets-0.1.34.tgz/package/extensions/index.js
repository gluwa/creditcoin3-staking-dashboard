var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var _a, _b;
import Enkrypt from "./jsx/Enkrypt";
import FearlessWallet from "./jsx/FearlessWallet";
import MetaMask from "./jsx/MetaMask";
import NovaWallet from "./jsx/NovaWallet";
import PolkadotJS from "./jsx/PolkadotJS";
import PolkaGate from "./jsx/PolkaGate";
import SubwalletJS from "./jsx/SubwalletJS";
import Talisman from "./jsx/Talisman";
import Ledger from "./jsx/Ledger";
import PolkadotVault from "./jsx/PolkadotVault";
import WalletConnect from "./jsx/WalletConnect";
export var Extensions = {
    enkrypt: {
        title: "Enkrypt",
        website: "enkrypt.com",
        features: "*",
    },
    "fearless-wallet": {
        title: "Fearless Wallet",
        website: "fearlesswallet.io",
        features: "*",
    },
    "metamask-polkadot-snap": {
        title: "MetaMask Polkadot Snap",
        website: [
            "snaps.metamask.io",
            "snaps.metamask.io/snap/npm/chainsafe/polkadot-snap",
        ],
        features: ["getAccounts", "signer"],
    },
    polkagate: {
        title: "PolkaGate",
        website: "polkagate.xyz",
        features: "*",
    },
    "subwallet-js": {
        title: "SubWallet",
        website: "subwallet.app",
        features: "*",
    },
    talisman: {
        title: "Talisman",
        website: "talisman.xyz",
        features: "*",
    },
    "polkadot-js": {
        title: ((_a = window === null || window === void 0 ? void 0 : window.walletExtension) === null || _a === void 0 ? void 0 : _a.isNovaWallet)
            ? "Nova Wallet"
            : "Polkadot JS",
        website: ((_b = window === null || window === void 0 ? void 0 : window.walletExtension) === null || _b === void 0 ? void 0 : _b.isNovaWallet)
            ? "novawallet.io"
            : "polkadot.js.org/extension",
        features: "*",
    },
};
export var ExtensionsArray = Object.entries(Extensions).map(function (_a) {
    var key = _a[0], value = _a[1];
    return (__assign({ id: key }, value));
});
export var ExtensionIcons = {
    enkrypt: Enkrypt,
    "fearless-wallet": FearlessWallet,
    "metamask-polkadot-snap": MetaMask,
    novawallet: NovaWallet,
    "polkadot-js": PolkadotJS,
    polkagate: PolkaGate,
    "subwallet-js": SubwalletJS,
    talisman: Talisman,
};
export var Hardware = {
    ledger: {
        title: "Ledger",
        website: "ledger.com",
    },
    polkadotvault: {
        title: "Polkadot Vault",
        website: "signer.parity.io/",
    },
    walletconnect: {
        title: "WalletConnect",
        website: "walletconnect.com",
    },
};
export var HardwareArray = Object.entries(Hardware).map(function (_a) {
    var key = _a[0], value = _a[1];
    return (__assign({ id: key }, value));
});
export var HardwareIcons = {
    ledger: Ledger,
    polkadotvault: PolkadotVault,
    walletconnect: WalletConnect,
};
export var getExtensionIcon = function (id) {
    var _a;
    if (id === "polkadot-js" && ((_a = window === null || window === void 0 ? void 0 : window.walletExtension) === null || _a === void 0 ? void 0 : _a.isNovaWallet))
        id = "novawallet";
    return ExtensionIcons[id] || null;
};


