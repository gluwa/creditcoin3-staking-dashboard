export type AnyJson = any;
export type AnyObject = any;
export declare enum EvalMessages {
    GIBBERISH = "Input is not correct. Use numbers, floats or expression (e.g. 1k, 1.3m)",
    ZERO = "You cannot send 0 funds",
    SUCCESS = "",
    SYMBOL_ERROR = "Provided symbol is not correct",
    GENERAL_ERROR = "Check your input. Something went wrong"
}
