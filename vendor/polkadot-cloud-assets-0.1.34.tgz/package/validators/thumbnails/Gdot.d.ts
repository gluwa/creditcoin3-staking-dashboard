declare const Gdot: () => import("react/jsx-runtime").JSX.Element;
export default Gdot;
