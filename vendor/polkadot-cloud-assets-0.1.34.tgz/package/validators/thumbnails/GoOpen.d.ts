declare const GoOpen: () => import("react/jsx-runtime").JSX.Element;
export default GoOpen;
