import { decodeAddress, encodeAddress } from '@polkadot/keyring';
import { isHex, hexToU8a, u8aToString, u8aUnwrapBytes } from '@polkadot/util';
import { BigNumber } from 'bignumber.js';

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol */


function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

/* @license Copyright 2023 @paritytech/polkadot-cloud authors & contributors
SPDX-License-Identifier: GPL-3.0-only */
var EvalMessages;
(function (EvalMessages) {
    EvalMessages["GIBBERISH"] = "Input is not correct. Use numbers, floats or expression (e.g. 1k, 1.3m)";
    EvalMessages["ZERO"] = "You cannot send 0 funds";
    EvalMessages["SUCCESS"] = "";
    EvalMessages["SYMBOL_ERROR"] = "Provided symbol is not correct";
    EvalMessages["GENERAL_ERROR"] = "Check your input. Something went wrong";
})(EvalMessages || (EvalMessages = {}));

/* @license Copyright 2023 @paritytech/polkadot-cloud authors & contributors
SPDX-License-Identifier: GPL-3.0-only */
var remToUnit = function (rem) {
    return Number(rem.slice(0, rem.length - 3)) *
        parseFloat(getComputedStyle(document.documentElement).fontSize);
};
var planckToUnit = function (val, units) {
    return new BigNumber(val.dividedBy(new BigNumber(10).exponentiatedBy(units)).toFixed(units));
};
var unitToPlanck = function (val, units) {
    var init = new BigNumber(!val.length || !val ? "0" : val);
    return (!init.isNaN() ? init : new BigNumber(0))
        .multipliedBy(new BigNumber(10).exponentiatedBy(units))
        .integerValue();
};
var minDecimalPlaces = function (val, minDecimals) {
    var whole = new BigNumber(rmCommas(val).split(".")[0] || 0);
    var decimals = val.split(".")[1] || "";
    var missingDecimals = new BigNumber(minDecimals).minus(decimals.length);
    return missingDecimals.isGreaterThan(0)
        ? "".concat(whole.toFormat(0), ".").concat(decimals.toString()).concat("0".repeat(missingDecimals.toNumber()))
        : val;
};
var rmCommas = function (val) { return val.replace(/,/g, ""); };
var greaterThanZero = function (val) { return val.isGreaterThan(0); };
var isNotZero = function (val) { return !val.isZero(); };
var shuffle = function (array) {
    var _a;
    var currentIndex = array.length;
    var randomIndex;
    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        _a = [
            array[randomIndex],
            array[currentIndex],
        ], array[currentIndex] = _a[0], array[randomIndex] = _a[1];
    }
    return array;
};
var pageFromUri = function (pathname, fallback) {
    var lastUriItem = pathname.substring(pathname.lastIndexOf("/") + 1);
    var page = lastUriItem.trim() === "" ? fallback : lastUriItem;
    return page.trim();
};
var capitalizeFirstLetter = function (string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
};
var snakeToCamel = function (str) {
    return str
        .toLowerCase()
        .replace(/([-_][a-z])/g, function (group) {
        return group.toUpperCase().replace("-", "").replace("_", "");
    });
};
var setStateWithRef = function (value, setState, ref) {
    setState(value);
    ref.current = value;
};
var localStorageOrDefault = function (key, _default, parse) {
    if (parse === void 0) { parse = false; }
    var val = localStorage.getItem(key);
    if (val === null) {
        return _default;
    }
    if (parse) {
        return JSON.parse(val);
    }
    return val;
};
var isValidAddress = function (address) {
    try {
        encodeAddress(isHex(address) ? hexToU8a(address) : decodeAddress(address));
        return true;
    }
    catch (e) {
        return false;
    }
};
var determinePoolDisplay = function (address, batchItem) {
    var defaultDisplay = ellipsisFn(address, 6);
    var display = batchItem !== null && batchItem !== void 0 ? batchItem : defaultDisplay;
    var displayAsBytes = u8aToString(u8aUnwrapBytes(display));
    if (displayAsBytes !== "") {
        display = displayAsBytes;
    }
    if (display === "") {
        display = defaultDisplay;
    }
    return display;
};
var extractUrlValue = function (key, url) {
    if (typeof url === "undefined")
        url = window.location.href;
    var match = url.match("[?&]".concat(key, "=([^&]+)"));
    return match ? match[1] : null;
};
var camelize = function (str) {
    var _a;
    var convertToString = function (string) {
        if (string) {
            if (typeof string === "string")
                return string;
            return String(string);
        }
        return "";
    };
    var toWords = function (inp) {
        return convertToString(inp).match(/[A-Z\xC0-\xD6\xD8-\xDE]?[a-z\xDF-\xF6\xF8-\xFF]+|[A-Z\xC0-\xD6\xD8-\xDE]+(?![a-z\xDF-\xF6\xF8-\xFF])|\d+/g);
    };
    var simpleCamelCase = function (inp) {
        var result = "";
        for (var i = 0; i < (inp === null || inp === void 0 ? void 0 : inp.length); i++) {
            var currString = inp[i];
            var tmpStr = currString.toLowerCase();
            if (i != 0) {
                tmpStr =
                    tmpStr.slice(0, 1).toUpperCase() + tmpStr.slice(1, tmpStr.length);
            }
            result += tmpStr;
        }
        return result;
    };
    var w = (_a = toWords(str)) === null || _a === void 0 ? void 0 : _a.map(function (a) { return a.toLowerCase(); });
    return simpleCamelCase(w);
};
var varToUrlHash = function (key, val, addIfMissing) {
    var hash = window.location.hash;
    var _a = hash.split("?"), page = _a[0], params = _a[1];
    var searchParams = new URLSearchParams(params);
    if (searchParams.get(key) === null && !addIfMissing) {
        return;
    }
    searchParams.set(key, val);
    window.location.hash = "".concat(page, "?").concat(searchParams.toString());
};
var removeVarFromUrlHash = function (key) {
    var hash = window.location.hash;
    var _a = hash.split("?"), page = _a[0], params = _a[1];
    var searchParams = new URLSearchParams(params);
    if (searchParams.get(key) === null) {
        return;
    }
    searchParams.delete(key);
    var paramsAsStr = searchParams.toString();
    window.location.hash = "".concat(page).concat(paramsAsStr ? "?".concat(paramsAsStr) : "");
};
var sortWithNull = function (ascending) { return function (a, b) {
    if (a === b) {
        return 0;
    }
    if (a === null) {
        return 1;
    }
    if (b === null) {
        return -1;
    }
    if (ascending) {
        return a < b ? -1 : 1;
    }
    return a < b ? 1 : -1;
}; };
var applyWidthAsPadding = function (subjectRef, containerRef) {
    if (containerRef.current && subjectRef.current) {
        containerRef.current.style.paddingRight = "".concat(subjectRef.current.offsetWidth + remToUnit("1rem"), "px");
    }
};
var unescape = function (val) { return val.replace(/\\"/g, '"'); };
var inChrome = function () {
    var isChromium = (window === null || window === void 0 ? void 0 : window.chrome) || null;
    var winNav = (window === null || window === void 0 ? void 0 : window.navigator) || null;
    var isOpera = typeof (window === null || window === void 0 ? void 0 : window.opr) !== "undefined";
    var isIEedge = (winNav === null || winNav === void 0 ? void 0 : winNav.userAgent.indexOf("Edg")) > -1 || false;
    var isIOSChrome = (winNav === null || winNav === void 0 ? void 0 : winNav.userAgent.match("CriOS")) || false;
    if (isIOSChrome) {
        return true;
    }
    if (isChromium !== null &&
        typeof isChromium !== "undefined" &&
        isOpera === false &&
        isIEedge === false) {
        return true;
    }
    return false;
};
var addedTo = function (fresh, stale, keys) {
    return typeof fresh !== "object" || typeof stale !== "object" || !keys.length
        ? []
        : fresh.filter(function (freshItem) {
            return !stale.find(function (staleItem) {
                return keys.every(function (key) {
                    return !(key in staleItem) || !(key in freshItem)
                        ? false
                        : staleItem[key] === freshItem[key];
                });
            });
        });
};
var removedFrom = function (fresh, stale, keys) {
    return typeof fresh !== "object" || typeof stale !== "object" || !keys.length
        ? []
        : stale.filter(function (staleItem) {
            return !fresh.find(function (freshItem) {
                return keys.every(function (key) {
                    return !(key in staleItem) || !(key in freshItem)
                        ? false
                        : freshItem[key] === staleItem[key];
                });
            });
        });
};
var matchedProperties = function (objX, objY, keys) {
    return typeof objX !== "object" || typeof objY !== "object" || !keys.length
        ? []
        : objY.filter(function (x) {
            return objX.find(function (y) {
                return keys.every(function (key) {
                    return !(key in x) || !(key in y) ? false : y[key] === x[key];
                });
            });
        });
};
var isValidHttpUrl = function (string) {
    var url;
    try {
        url = new URL(string);
    }
    catch (_) {
        return false;
    }
    return url.protocol === "http:" || url.protocol === "https:";
};
var makeCancelable = function (promise) {
    var hasCanceled = false;
    var wrappedPromise = new Promise(function (resolve, reject) {
        promise.then(function (val) {
            return hasCanceled ? reject(Error("Cancelled")) : resolve(val);
        });
        promise.catch(function (error) {
            return hasCanceled ? reject(Error("Cancelled")) : reject(error);
        });
    });
    return {
        promise: wrappedPromise,
        cancel: function () {
            hasCanceled = true;
        },
    };
};
var ellipsisFn = function (str, amount, position) {
    if (amount === void 0) { amount = 6; }
    if (position === void 0) { position = "center"; }
    var half = str.length / 2;
    if (amount <= 4) {
        if (position === "center")
            return str.slice(0, 4) + "..." + str.slice(-4);
        if (position === "end")
            return str.slice(0, 4) + "...";
        return "..." + str.slice(-4);
    }
    if (position === "center") {
        return amount >= (str.length - 2) / 2
            ? str.slice(0, half - 3) + "..." + str.slice(-(half - 3))
            : str.slice(0, amount) + "..." + str.slice(-amount);
    }
    if (amount >= str.length) {
        if (position === "end")
            return str.slice(0, str.length - 3) + "...";
        return "..." + str.slice(-(str.length - 3));
    }
    else {
        if (position === "end")
            return str.slice(0, amount) + "...";
        return "..." + str.slice(amount);
    }
};
var getSiValue = function (si) {
    return new BigNumber(10).pow(new BigNumber(si));
};
var si = [
    { value: getSiValue(24), symbol: "y", isMil: true },
    { value: getSiValue(21), symbol: "z", isMil: true },
    { value: getSiValue(18), symbol: "a", isMil: true },
    { value: getSiValue(15), symbol: "f", isMil: true },
    { value: getSiValue(12), symbol: "p", isMil: true },
    { value: getSiValue(9), symbol: "n", isMil: true },
    { value: getSiValue(6), symbol: "μ", isMil: true },
    { value: getSiValue(3), symbol: "m", isMil: true },
    { value: new BigNumber(1), symbol: "" },
    { value: getSiValue(3), symbol: "k" },
    { value: getSiValue(6), symbol: "M" },
    { value: getSiValue(9), symbol: "G" },
    { value: getSiValue(12), symbol: "T" },
    { value: getSiValue(15), symbol: "P" },
    { value: getSiValue(18), symbol: "E" },
    { value: getSiValue(21), symbol: "Y" },
    { value: getSiValue(24), symbol: "Z" },
];
var allowedSymbols = si
    .map(function (s) { return s.symbol; })
    .join(", ")
    .replace(", ,", ",");
var floats = new RegExp("^[+]?[0-9]*[.,]{1}[0-9]*$");
var ints = new RegExp("^[+]?[0-9]+$");
var alphaFloats = new RegExp("^[+]?[0-9]*[.,]{1}[0-9]*[" + allowedSymbols + "]{1}$");
var alphaInts = new RegExp("^[+]?[0-9]*[" + allowedSymbols + "]{1}$");
var evalUnits = function (input, chainDecimals) {
    input = input && input.replace("+", "");
    if (!floats.test(input) &&
        !ints.test(input) &&
        !alphaInts.test(input) &&
        !alphaFloats.test(input)) {
        return [null, EvalMessages.GIBBERISH];
    }
    var symbol = input.replace(/[0-9.,]/g, "");
    var siVal = si.find(function (s) { return s.symbol === symbol; });
    var numberStr = input.replace(symbol, "").replace(",", ".");
    var numeric = new BigNumber(0);
    if (!siVal) {
        return [null, EvalMessages.SYMBOL_ERROR];
    }
    var decimalsBn = new BigNumber(10).pow(new BigNumber(chainDecimals));
    var containDecimal = numberStr.includes(".");
    var _a = numberStr.split("."), decPart = _a[0], fracPart = _a[1];
    var fracDecimals = (fracPart === null || fracPart === void 0 ? void 0 : fracPart.length) || 0;
    var fracExp = new BigNumber(10).pow(new BigNumber(fracDecimals));
    numeric = containDecimal
        ? new BigNumber(new BigNumber(decPart)
            .multipliedBy(fracExp)
            .plus(new BigNumber(fracPart)))
        : new BigNumber(new BigNumber(numberStr));
    numeric = numeric.multipliedBy(decimalsBn);
    if (containDecimal) {
        numeric = siVal.isMil
            ? numeric.dividedBy(siVal.value).dividedBy(fracExp)
            : numeric.multipliedBy(siVal.value).dividedBy(fracExp);
    }
    else {
        numeric = siVal.isMil
            ? numeric.dividedBy(siVal.value)
            : numeric.multipliedBy(siVal.value);
    }
    if (numeric.eq(new BigNumber(0))) {
        return [null, EvalMessages.ZERO];
    }
    return [numeric, EvalMessages.SUCCESS];
};
var transformToBaseUnit = function (estFee, chainDecimals) {
    var t = estFee.length - chainDecimals;
    var s = "";
    if (t < 0) {
        for (var i = 0; i < Math.abs(t) - 1; i++) {
            s += "0";
        }
        s = s + estFee;
        for (var i = 0; i < s.length; i++) {
            if (s.slice(s.length - 1) !== "0")
                break;
            s = s.substring(0, s.length - 1);
        }
        s = "0." + s;
    }
    else {
        s = (parseInt(estFee) / Math.pow(10, chainDecimals)).toString();
    }
    return parseFloat(s) !== 0 ? s : "0";
};
var unimplemented = function (_a) {
    __rest(_a, []);
};
var mergeDeep = function (target) {
    var _a, _b;
    var sources = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        sources[_i - 1] = arguments[_i];
    }
    if (!sources.length)
        return target;
    var isObject = function (item) {
        return item && typeof item === "object" && !Array.isArray(item);
    };
    var source = sources.shift();
    if (isObject(target) && isObject(source)) {
        for (var key in source) {
            if (isObject(source[key])) {
                if (!target[key])
                    Object.assign(target, (_a = {}, _a[key] = {}, _a));
                mergeDeep(target[key], source[key]);
            }
            else {
                Object.assign(target, (_b = {}, _b[key] = source[key], _b));
            }
        }
    }
    return mergeDeep.apply(void 0, __spreadArray([target], sources, false));
};

export { addedTo, applyWidthAsPadding, camelize, capitalizeFirstLetter, determinePoolDisplay, ellipsisFn, evalUnits, extractUrlValue, greaterThanZero, inChrome, isNotZero, isValidAddress, isValidHttpUrl, localStorageOrDefault, makeCancelable, matchedProperties, mergeDeep, minDecimalPlaces, pageFromUri, planckToUnit, remToUnit, removeVarFromUrlHash, removedFrom, rmCommas, setStateWithRef, shuffle, snakeToCamel, sortWithNull, transformToBaseUnit, unescape, unimplemented, unitToPlanck, varToUrlHash };
