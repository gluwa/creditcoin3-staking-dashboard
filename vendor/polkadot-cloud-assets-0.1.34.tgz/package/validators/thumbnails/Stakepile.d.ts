declare const Stakepile: () => import("react/jsx-runtime").JSX.Element;
export default Stakepile;
