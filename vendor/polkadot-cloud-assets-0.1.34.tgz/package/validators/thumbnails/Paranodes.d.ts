declare const Paranodes: () => import("react/jsx-runtime").JSX.Element;
export default Paranodes;
