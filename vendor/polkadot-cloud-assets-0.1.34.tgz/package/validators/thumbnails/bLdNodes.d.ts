declare const IconBldnodes: () => import("react/jsx-runtime").JSX.Element;
export default IconBldnodes;
